/*
Package pluginutils provides libraries to implement malice golang based plugins.
*/
package pluginutils
