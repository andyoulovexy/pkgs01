# pkgs

[![GitHub Tag][tag]](https://github.com/malice-plugins/pkgs)
[![GoDoc][godoc]](https://godoc.org/github.com/malice-plugins/pkgs)
[![License][license]](http://www.apache.org/licenses/LICENSE-2.0)

> Collection of utility packages used by the Malice project and Malice Plugins

---

[license]: https://img.shields.io/badge/licence-Apache%202.0-blue.svg
[godoc]: https://godoc.org/github.com/malice-plugins/pkgs?status.svg
[tag]: https://img.shields.io/github/tag/malice-plugins/pkgs.svg
